package com.limonchik.escooter

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    val ble = BleClient(app)

    var scooter by mutableStateOf(prefs.scooter)
    var onboarded by mutableStateOf(prefs.onboarded)
    var theme by mutableIntStateOf(prefs.theme)
    var mph by mutableStateOf(prefs.mph)
    var keepOn by mutableStateOf(prefs.keepOn)
    var lowAlert by mutableStateOf(prefs.lowAlert)
    var speedAlert by mutableIntStateOf(prefs.speedAlert)
    var strobeMode by mutableIntStateOf(prefs.strobeMode.coerceIn(0, StrobeMode.values().lastIndex))
    var strobeSpeed by mutableFloatStateOf(prefs.strobeSpeed)
    var showTg by mutableStateOf(false)
    var showBotRegistration by mutableStateOf(false)
    var scanOpen by mutableStateOf(false)
    val userAsked get() = prefs.userAsked

    init { ble.onConnected = { prefs.lastAddr = it } }

    /** Предложение подписаться на канал: ровно один раз, после регистрации. */
    fun maybeShowTg() { if (!prefs.tgPrompted) { showTg = true; prefs.tgPrompted = true } }
    fun dismissTg() { showTg = false }
    fun setScooter(n: String) { scooter = n; prefs.scooter = n }
    fun saveUser(u: String) {
        prefs.username = u.trim().removePrefix("@").filter { it.isLetterOrDigit() || it == '_' }
    }
    fun finishOnboarding() { prefs.userAsked = true; prefs.onboarded = true; onboarded = true }
    /** Показывает приглашение отправить данные боту только при первой регистрации. */
    fun registerOnce() {
        if (!prefs.botSent) {
            prefs.botSent = true
            showBotRegistration = true
        }
    }
    fun dismissBotRegistration() { showBotRegistration = false }
    fun registrationMessage(): String {
        val username = prefs.username?.takeIf { it.isNotBlank() }?.let { "@$it" }
            ?: "(укажите свой Telegram username)"
        val model = scooter?.takeIf { it.isNotBlank() } ?: "Другая модель"
        return "Здравствуйте! Мой Telegram: $username\nМодель электросамоката: $model\nПриложение: E-scooter App\nАвтор приложения: limonchik"
    }
    fun changeScooter() { prefs.onboarded = false; onboarded = false }
    fun setTheme(i: Int) { theme = i; prefs.theme = i }
    fun setMph(v: Boolean) { mph = v; prefs.mph = v }
    fun setKeepOn(v: Boolean) { keepOn = v; prefs.keepOn = v }
    fun setLowAlert(v: Boolean) { lowAlert = v; prefs.lowAlert = v }
    fun setSpeedAlert(v: Int) { speedAlert = v; prefs.speedAlert = v }
    fun setStrobeMode(v: Int) { strobeMode = v; prefs.strobeMode = v }
    fun setStrobeSpeed(v: Float) { strobeSpeed = v; prefs.strobeSpeed = v }
    fun openScan() { scanOpen = true; ble.startScan() }
    fun closeScan() { scanOpen = false; ble.stopScan() }
    fun connect(addr: String) { scanOpen = false; ble.connect(addr, scooter) }
    fun autoConnect() {
        val a = prefs.lastAddr ?: return
        val st = ble.state.value
        if ((st == ConnState.IDLE || st == ConnState.ERROR) && !ble.userDisconnected) ble.connect(a, scooter)
    }

    override fun onCleared() { ble.close() }
}
