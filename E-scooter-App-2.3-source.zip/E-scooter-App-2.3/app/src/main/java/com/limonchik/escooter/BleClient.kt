package com.limonchik.escooter

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.UUID

enum class ConnState { IDLE, SCANNING, CONNECTING, CONNECTED, ERROR }
data class Found(val name: String, val addr: String, val rssi: Int, val likely: Boolean, val brand: String = "")
data class DeviceInfo(val serial: String = "", val fw: String = "")

@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class BleClient(private val ctx: Context) {
    companion object {
        val NUS_SVC: UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
        val NUS_RX: UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e")
        val NUS_TX: UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        val HINTS = listOf("miscooter", "ninebot", "nbscooter", "segway", "xiaomi", "m365", "kugoo", "kirin", "jilong", "scooter")
        val UART_UUIDS = listOf("6e400001", "0000fe95", "0000ffe0", "0000fff0")
        fun hex(b: ByteArray) = b.joinToString(" ") { "%02X".format(it) }
    }

    val state = MutableStateFlow(ConnState.IDLE)
    val found = MutableStateFlow<List<Found>>(emptyList())
    val data = MutableStateFlow(Telemetry())
    val noData = MutableStateFlow(false)
    val light = MutableStateFlow(false)
    val locked = MutableStateFlow(false)
    val msg = MutableStateFlow("")
    val log = MutableStateFlow<List<String>>(emptyList())
    val protoOk = MutableStateFlow(false)
    val rawBytes = MutableStateFlow(0)
    val info = MutableStateFlow(DeviceInfo())
    val gattDump = MutableStateFlow<List<String>>(emptyList())
    val frames = MutableStateFlow<List<String>>(emptyList())
    val strobe = MutableStateFlow(false)
    val stats = MutableStateFlow(Stats())
    val kers = MutableStateFlow(-1)
    val cruise = MutableStateFlow(false)
    var onConnected: ((String) -> Unit)? = null

    private val h = Handler(Looper.getMainLooper())
    private val mgr = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private var gatt: BluetoothGatt? = null
    private var wr: BluetoothGattCharacteristic? = null
    private var mtu = 23
    private var userDisc = false
    private var discStarted = false
    private var addr: String? = null
    private var retries = 0
    private var lastRx = 0L
    private var lastTelemetryAt = 0L
    private var connectedAt = 0L
    private var tick = 0
    private var rxBuf = ByteArray(0)
    private val devs = LinkedHashMap<String, Found>()
    private val queue = ArrayDeque<ByteArray>()
    private var pumping = false
    private var inFlight = false
    private var writeToken = 0
    private var rxChunks = 0
    private var autoMode = false
    private var protocolEnabled = false
    private var protocolChannelFound = false
    private var strobeSteps: List<Pair<Boolean, Long>> = emptyList()
    private var strobeIdx = 0
    private var strobeK = 1f

    val userDisconnected: Boolean get() = userDisc

    private fun addLog(s: String) { log.value = (log.value + s).takeLast(40) }
    private fun addFrame(s: String) { frames.value = (frames.value + s).takeLast(60) }
    fun clearFrames() { frames.value = emptyList(); log.value = emptyList() }

    private fun guessBrand(n: String): String {
        val s = n.lowercase()
        return when {
            s.contains("kugoo") || s.contains("kirin") || s.contains("jilong") -> "Kugoo"
            s.contains("ninebot") || s.contains("nbscooter") || s.contains("segway") -> "Ninebot"
            s.contains("miscooter") || s.contains("xiaomi") || s.contains("m365") -> "Xiaomi"
            else -> ""
        }
    }

    private fun propsStr(p: Int): String {
        val l = ArrayList<String>()
        if ((p and 0x02) != 0) l.add("R")
        if ((p and 0x08) != 0) l.add("W")
        if ((p and 0x04) != 0) l.add("Wnr")
        if ((p and 0x10) != 0) l.add("N")
        if ((p and 0x20) != 0) l.add("I")
        return l.joinToString("/")
    }

    private fun dumpServices(g: BluetoothGatt) {
        val out = ArrayList<String>()
        for (sv in g.services) {
            out.add("S " + sv.uuid.toString().take(8))
            for (c in sv.characteristics) out.add("   C " + c.uuid.toString().take(8) + " " + propsStr(c.properties))
        }
        gattDump.value = out
    }

    /** Отчёт для поддержки: без серийного номера, MAC обрезан до производителя. */
    fun report(model: String, family: String): String {
        val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (_: Throwable) { "?" }
        val a = addr?.let { it.take(8) + ":xx:xx:xx" } ?: "-"
        val sb = StringBuilder()
        sb.append("E-scooter App ").append(ver).append(" (автор: limonchik)\n")
        sb.append("Android ").append(Build.VERSION.RELEASE).append(" (").append(Build.MODEL).append(")\n")
        sb.append("Модель: ").append(model).append("\nПрофиль: ").append(family).append("\n")
        sb.append("MAC: ").append(a).append("\nMTU: ").append(mtu).append("\n")
        sb.append("Протокол M365 отвечает: ").append(if (protoOk.value) "да" else "нет").append("\n")
        sb.append("Принято байт: ").append(rawBytes.value).append("\n")
        if (info.value.fw.isNotEmpty()) sb.append("Прошивка: ").append(info.value.fw).append("\n")
        sb.append("\n— GATT —\n").append(gattDump.value.joinToString("\n"))
        sb.append("\n\n— Кадры —\n").append(frames.value.joinToString("\n"))
        sb.append("\n\n— Журнал —\n").append(log.value.joinToString("\n"))
        return sb.toString()
    }

    // ---------- scan ----------
    private val stopRunnable = Runnable { stopScan() }
    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val n = r.device.name ?: r.scanRecord?.deviceName ?: ""
            val ids = r.scanRecord?.serviceUuids?.map { it.uuid.toString().lowercase() } ?: emptyList()
            val likely = HINTS.any { n.contains(it, true) } || ids.any { id -> UART_UUIDS.any { id.startsWith(it) } }
            devs[r.device.address] = Found(n, r.device.address, r.rssi, likely, guessBrand(n))
            found.value = devs.values.sortedWith(compareByDescending<Found> { it.likely }.thenByDescending { it.rssi })
        }
        override fun onScanFailed(code: Int) { msg.value = "Ошибка сканирования ($code)"; state.value = ConnState.ERROR }
    }

    fun startScan() {
        val ad = mgr.adapter
        if (ad == null || !ad.isEnabled) { msg.value = "Включите Bluetooth"; return }
        val sc = ad.bluetoothLeScanner ?: return
        devs.clear(); found.value = emptyList(); msg.value = ""
        try { sc.stopScan(scanCb) } catch (_: Throwable) {}
        sc.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCb)
        if (state.value != ConnState.CONNECTED) state.value = ConnState.SCANNING
        h.removeCallbacks(stopRunnable); h.postDelayed(stopRunnable, 12000)
    }

    fun stopScan() {
        h.removeCallbacks(stopRunnable)
        try { mgr.adapter?.bluetoothLeScanner?.stopScan(scanCb) } catch (_: Throwable) {}
        if (state.value == ConnState.SCANNING) state.value = ConnState.IDLE
    }

    // ---------- connect ----------
    private val connTimeout = Runnable { if (state.value == ConnState.CONNECTING) handleDrop(-1) }

    fun connect(a: String, model: String?) {
        stopScan()
        userDisc = false
        retries = 0
        autoMode = false
        addr = a
        protocolEnabled = profileFor(model).family == Family.M365
        open(a)
    }

    private fun open(a: String) {
        val ad = mgr.adapter
        if (ad == null || !ad.isEnabled) { fail("Включите Bluetooth"); return }
        state.value = ConnState.CONNECTING; msg.value = ""; discStarted = false; mtu = 23
        protocolChannelFound = false
        protoOk.value = false
        closeGatt()
        val dev = try { mgr.adapter.getRemoteDevice(a) } catch (e: Exception) { fail("Неверный адрес"); return }
        gatt = if (Build.VERSION.SDK_INT >= 23) dev.connectGatt(ctx, autoMode, cb, BluetoothDevice.TRANSPORT_LE)
        else dev.connectGatt(ctx, autoMode, cb)
        addLog("connect $a")
        h.removeCallbacks(connTimeout); h.postDelayed(connTimeout, 15000)
    }

    private fun startDiscovery(g: BluetoothGatt) {
        if (discStarted) return
        discStarted = true
        try { g.javaClass.getMethod("refresh").invoke(g) } catch (_: Throwable) {}
        g.discoverServices()
        h.removeCallbacks(discTimeout); h.postDelayed(discTimeout, 10000)
    }

    private val discTimeout = Runnable {
        if (state.value == ConnState.CONNECTING && wr == null) { addLog("services timeout"); handleDrop(-2) }
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            h.post {
                if (g !== gatt) return@post
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    addLog("connected st=$status")
                    try { g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH) } catch (_: Throwable) {}
                    if (!g.requestMtu(185)) startDiscovery(g)
                    h.postDelayed({ startDiscovery(g) }, 1500)
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    addLog("disconnected st=$status"); handleDrop(status)
                }
            }
        }
        override fun onMtuChanged(g: BluetoothGatt, m: Int, status: Int) {
            h.post { if (g === gatt) { mtu = m; addLog("mtu=$m"); startDiscovery(g) } }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            h.post {
                if (g !== gatt) return@post
                if (status != BluetoothGatt.GATT_SUCCESS) { addLog("services st=$status"); handleDrop(status) }
                else { dumpServices(g); setup(g) }
            }
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            h.post { if (g === gatt && inFlight) { inFlight = false; writeToken++; pumpStep() } }
        }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) { h.post { ready() } }
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value ?: return
            h.post { rx(v) }
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            h.post { rx(value) }
        }
    }

    private fun setup(g: BluetoothGatt) {
        h.removeCallbacks(discTimeout)
        var notify: BluetoothGattCharacteristic? = null
        var write: BluetoothGattCharacteristic? = null

        // Prefer the Nordic UART service, then search for a notify/write pair inside one service.
        g.getService(NUS_SVC)?.let { service ->
            notify = service.getCharacteristic(NUS_TX)
            write = service.getCharacteristic(NUS_RX)
        }
        if (notify == null || write == null) {
            addLog("searching compatible BLE characteristic pair")
            val services = g.services.sortedBy { service ->
                val u = service.uuid.toString().lowercase()
                when {
                    u.startsWith("0000ffe0") -> 0
                    u.startsWith("0000fff0") -> 1
                    u.startsWith("0000fe95") -> 2
                    else -> 3
                }
            }
            for (service in services) {
                val su = service.uuid.toString().lowercase()
                if (su.startsWith("00001800") || su.startsWith("00001801")) continue
                val chars = service.characteristics
                val n = chars.firstOrNull { c ->
                    (c.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE)) != 0
                }
                val w = chars.firstOrNull { c ->
                    c.uuid != n?.uuid &&
                        (c.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0
                }
                if (n != null && w != null) {
                    notify = n
                    write = w
                    addLog("UART pair in service ${su.take(8)}")
                    break
                }
            }
        }
        val n = notify
        val w = write
        if (n == null || w == null) {
            wr = null
            protocolChannelFound = false
            addLog("GATT открыт, но подходящая пара notify/write не найдена")
            ready() // сохраняем BLE-соединение и показываем GATT-диагностику даже без UART
            noData.value = true
            msg.value = "BLE подключён, но канал обмена данными этой модели пока не поддерживается"
            return
        }
        protocolChannelFound = true
        wr = w
        g.setCharacteristicNotification(n, true)
        val d = n.getDescriptor(CCCD)
        if (d == null) { ready(); return }
        d.value = if ((n.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0)
            BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
        if (!g.writeDescriptor(d)) {
            addLog("CCCD write pending; using connected state")
            h.postDelayed({ if (state.value == ConnState.CONNECTING) ready() }, 800)
        } else {
            h.postDelayed({ if (state.value == ConnState.CONNECTING) ready() }, 1800)
        }
    }

    private fun ready() {
        if (state.value == ConnState.CONNECTED) return
        h.removeCallbacks(connTimeout)
        state.value = ConnState.CONNECTED; retries = 0; lastRx = 0; tick = 0
        noData.value = false; msg.value = ""; connectedAt = System.currentTimeMillis()
        lastTelemetryAt = 0L
        protoOk.value = false; rawBytes.value = 0; rxChunks = 0; rxBuf = ByteArray(0); info.value = DeviceInfo()
        stats.value = Stats(); strobe.value = false; kers.value = -1; cruise.value = false
        addr?.let { onConnected?.invoke(it) }
        h.removeCallbacks(poll)
        if (protocolEnabled && protocolChannelFound) {
            h.post(poll)
            h.postDelayed({
                if (state.value == ConnState.CONNECTED && protocolEnabled) {
                    send(Protocol.read(0x10, 14))
                    send(Protocol.read(0x1A, 2))
                }
            }, 1200)
        } else if (!protocolEnabled) {
            addLog("BLE connected; model protocol is not enabled")
            msg.value = "BLE подключён · протокол управления для этой модели не подтверждён"
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            if (state.value != ConnState.CONNECTED || !protocolEnabled || !protocolChannelFound) return
            send(Protocol.read(0xB0, 0x20), true)
            if (tick++ % 5 == 0) send(Protocol.read(0x22, 2), true)
            if (!noData.value && !protoOk.value && lastRx == 0L && System.currentTimeMillis() - connectedAt > 6000) {
                noData.value = true; addLog("нет ответа протокола")
            }
            h.postDelayed(this, 450)
        }
    }

    private fun rx(v: ByteArray) {
        rawBytes.value = rawBytes.value + v.size
        rxBuf += v
        if (rxBuf.size > 512) rxBuf = ByteArray(0)
        val (fr, rest) = Protocol.parse(rxBuf)
        rxBuf = rest
        if (rxChunks++ < 25 || fr.isEmpty()) addFrame("RX " + hex(v))
        for (f in fr) {
            if (f.addr == 0x20) continue
            lastRx = System.currentTimeMillis(); noData.value = false; protoOk.value = true
            when (f.reg) {
                0xB0 -> Protocol.live(f.data, data.value)?.let {
                    data.value = it
                    lastTelemetryAt = System.currentTimeMillis()
                    track(it)
                }
                0x22 -> if (f.data.size >= 2) {
                    val b = (f.data[0].toInt() and 0xFF) or ((f.data[1].toInt() and 0xFF) shl 8)
                    if (b in 0..100) data.value = data.value.copy(battery = b)
                }
                0x10 -> {
                    val t = f.data.map { it.toInt() and 0xFF }.filter { it in 32..126 }.map { it.toChar() }.joinToString("")
                    if (t.isNotEmpty()) info.value = info.value.copy(serial = t)
                }
                0x1A -> if (f.data.size >= 2) {
                    val x = (f.data[0].toInt() and 0xFF) or ((f.data[1].toInt() and 0xFF) shl 8)
                    info.value = info.value.copy(fw = "${(x shr 8) and 0xF}.${(x shr 4) and 0xF}.${x and 0xF}")
                }
            }
        }
    }

    // ---------- write ----------
    fun send(b: ByteArray, quiet: Boolean = false) {
        if (!quiet) addFrame("TX " + hex(b))
        val size = (mtu - 3).coerceIn(20, 180)
        var i = 0
        while (i < b.size) { queue.add(b.copyOfRange(i, minOf(i + size, b.size))); i += size }
        if (!pumping) { pumping = true; pumpStep() }
    }

    private fun pumpStep() {
        val c = queue.removeFirstOrNull(); val w = wr; val g = gatt
        if (c == null || w == null || g == null) { pumping = false; inFlight = false; return }
        val noResp = (w.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
        w.writeType = if (noResp) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        w.value = c
        if (!g.writeCharacteristic(w)) {
            w.writeType = if (noResp) BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            if (!g.writeCharacteristic(w)) addLog("запись отклонена")
        }
        inFlight = true
        val t = ++writeToken
        // следующий пакет — по подтверждению записи, а если оно не пришло — по таймеру
        h.postDelayed({ if (t == writeToken) { inFlight = false; pumpStep() } }, if (noResp) 40L else 250L)
    }

    private fun track(d: Telemetry) {
        val now = System.currentTimeMillis()
        stats.value = stats.value.let { s ->
            s.copy(
                max = maxOf(s.max, d.speed),
                sum = if (d.speed > 1f) s.sum + d.speed else s.sum,
                n = if (d.speed > 1f) s.n + 1 else s.n,
                startBat = if (s.startBat < 0) d.battery else s.startBat,
                startMs = if (s.startMs == 0L) now else s.startMs
            )
        }
    }

    // Стробоскоп доступен только на подтверждённом M365-протоколе и на полной остановке.
    private val strobeTimeout = Runnable { stopStrobe(); msg.value = "Стробоскоп автоматически остановлен" }
    private val strobeRun = object : Runnable {
        override fun run() {
            if (!strobe.value || state.value != ConnState.CONNECTED || !protocolEnabled || !protocolChannelFound) {
                stopStrobe(false)
                return
            }
            val telemetryAge = System.currentTimeMillis() - lastTelemetryAt
            if (telemetryAge > 1500L) {
                stopStrobe()
                msg.value = "Стробоскоп остановлен: нет свежих данных о скорости"
                return
            }
            if (data.value.speed > 0.2f) {
                stopStrobe()
                msg.value = "Стробоскоп остановлен: обнаружено движение"
                return
            }
            if (strobeSteps.isEmpty()) { stopStrobe(); return }
            val (on, ms) = strobeSteps[strobeIdx % strobeSteps.size]
            strobeIdx++
            if (queue.size < 4) send(Protocol.write(0x7D, if (on) 2 else 0), true)
            h.postDelayed(this, (ms * strobeK).toLong().coerceAtLeast(250L))
        }
    }

    fun startStrobe(mode: StrobeMode, k: Float) {
        if (!protocolEnabled || !protocolChannelFound || !protoOk.value) { addLog("стробоскоп: протокол не подтверждён"); return }
        val telemetryAge = System.currentTimeMillis() - lastTelemetryAt
        if (telemetryAge > 1500L || lastTelemetryAt == 0L) {
            msg.value = "Стробоскоп недоступен: дождитесь свежих данных о скорости"
            return
        }
        if (data.value.speed > 0.1f) { msg.value = "Стробоскоп можно включить только после полной остановки"; return }
        strobeSteps = mode.steps
        strobeK = k.coerceIn(0.7f, 1.3f)
        strobeIdx = 0
        strobe.value = true
        h.removeCallbacks(strobeRun)
        h.removeCallbacks(strobeTimeout)
        h.post(strobeRun)
        h.postDelayed(strobeTimeout, 30_000L)
    }

    fun stopStrobe(sendOff: Boolean = true) {
        h.removeCallbacks(strobeRun)
        h.removeCallbacks(strobeTimeout)
        val was = strobe.value
        strobe.value = false
        if (was && sendOff && state.value == ConnState.CONNECTED && protocolEnabled && protocolChannelFound) {
            send(Protocol.write(0x7D, 0), true)
            light.value = false
        }
    }

    fun setKers(level: Int) {
        if (!protocolEnabled || !protocolChannelFound || !protoOk.value) return
        send(Protocol.write(0x7B, level)); kers.value = level
    }
    fun setCruise(on: Boolean) {
        if (!protocolEnabled || !protocolChannelFound || !protoOk.value) return
        send(Protocol.write(0x7C, if (on) 1 else 0)); cruise.value = on
    }
    fun shutdown() {
        if (!protocolEnabled || !protocolChannelFound || !protoOk.value) return
        send(Protocol.write(0x79, 1))
    }

    fun setLight(on: Boolean) {
        if (strobe.value) stopStrobe(false)
        if (!protocolEnabled || !protocolChannelFound || !protoOk.value) { addLog("свет: протокол не подтверждён"); return }
        send(Protocol.write(0x7D, if (on) 2 else 0)); light.value = on
    }
    fun setLock(on: Boolean) {
        if (!protocolEnabled || !protocolChannelFound || !protoOk.value) { addLog("замок: протокол не подтверждён"); return }
        send(Protocol.write(if (on) 0x70 else 0x71, 1)); locked.value = on
    }

    // ---------- teardown ----------
    private fun handleDrop(status: Int) {
        h.removeCallbacks(poll); h.removeCallbacks(connTimeout); h.removeCallbacks(discTimeout); stopStrobe(false)
        wr = null; queue.clear(); pumping = false; inFlight = false; writeToken++
        if (userDisc) { closeGatt(); state.value = ConnState.IDLE; return }
        val a = addr
        if (retries < 5 && a != null) {
            retries++; autoMode = retries >= 3; addLog("retry $retries (st=$status)")
            state.value = ConnState.CONNECTING; closeGatt()
            h.postDelayed({ if (!userDisc) open(a) }, 1000L * retries)
        } else {
            closeGatt(); state.value = ConnState.ERROR
            msg.value = "Соединение потеряно. Нажмите «Найти самокат»"
        }
    }

    private fun fail(m: String) { msg.value = m; addLog(m); h.removeCallbacks(connTimeout); closeGatt(); state.value = ConnState.ERROR }

    private fun closeGatt() {
        gatt?.let { try { it.disconnect() } catch (_: Throwable) {}; try { it.close() } catch (_: Throwable) {} }
        gatt = null
    }

    fun disconnect() {
        userDisc = true
        h.removeCallbacks(poll); h.removeCallbacks(connTimeout); h.removeCallbacks(discTimeout); stopStrobe(false)
        wr = null; queue.clear(); pumping = false; inFlight = false; writeToken++
        closeGatt(); state.value = ConnState.IDLE; data.value = Telemetry(); noData.value = false; protoOk.value = false; info.value = DeviceInfo(); lastTelemetryAt = 0L
    }

    fun close() { stopScan(); disconnect() }
}
